package di;

public interface ILogMessage {
	public void getMessage();
}
